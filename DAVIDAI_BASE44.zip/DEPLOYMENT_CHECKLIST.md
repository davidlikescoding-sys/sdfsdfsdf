# Deployment Checklist

## Already completed for this export

- Full project inspection: 17 page routes, 32 API route files / 47 handlers, SQLite schema v2, local AI runtimes, assets, configs, and scripts.
- Typecheck clean; 304 Vitest tests passed; production build succeeded.
- 17/17 pages returned HTTP 200; key APIs returned HTTP 200.
- Brain DB `integrity_check = ok`; consistent snapshot exported.
- Credential scan: no real secrets found.
- Both final ZIPs verified entry-by-entry; see `VERIFICATION_REPORT.md`.

## Before leaving the old browser

- [ ] Export Settings/user JSON from DavidAI.
- [ ] Save datasets, checkpoints, visual assets, image history, and video history from `localStorage`.
- [ ] Keep `DAVIDAI_COMPLETE.zip` as the offline master backup.

## Base44 setup

- [ ] Create a new Base44 app.
- [ ] Upload/attach `DAVIDAI_BASE44.zip` as context or source files.
- [ ] Recreate 17 pages and `AppShell` navigation.
- [ ] Recreate Tailwind theme, fonts, icons, and public dictionary asset.
- [ ] Create entities from `DATABASE_MIGRATION.md`.
- [ ] Import `DATA_EXPORT/brain_dump.json` or flattened CSVs.
- [ ] Verify counts against `counts.json`.
- [ ] Rewrite APIs from `API_INTEGRATIONS.md`.
- [ ] Preserve opt-in research and NDJSON/progress equivalents.
- [ ] Add Base44 auth and entity security rules.
- [ ] Configure secrets only if a provider is intentionally added.
- [ ] Decide local AI strategy: external worker, client-side model, or documented removal. Never fake generation.
- [ ] Test all pages, CRUD flows, imports/exports, and permissions.
- [ ] Publish only after preview QA.

## If using Base Code/GitHub instead

- [ ] Extract `DAVIDAI_COMPLETE.zip`.
- [ ] Create a GitHub repo, keeping large GGUF weights outside Git if needed.
- [ ] Connect the repo at <https://app.base44.com/base-code>.
- [ ] Treat the result as preview/development, not production hosting.
- [ ] Use your existing Next.js host for production unless Path Base44 reconstruction is completed.

## Final QA

- [ ] No `.env`, tokens, keys, or credentials in the project.
- [ ] Mutating endpoints require auth.
- [ ] No external AI request occurs by default.
- [ ] Generated media URLs return correct content types.
- [ ] Delete confirmations work.
- [ ] Import/export round-trip preserves JSON shapes.
