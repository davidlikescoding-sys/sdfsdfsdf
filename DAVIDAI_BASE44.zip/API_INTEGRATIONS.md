# API Integrations

DavidAI has 32 Next.js App Router route files under `src/app/api/**/route.ts`, containing 47 exported HTTP handlers. They use Node runtime, `node:sqlite`, child processes, and local Windows binaries. No paid API key is required.

Base44 does not convert Next handlers automatically. Rewrite them as TanStack Start server routes/server functions or Base44 backend functions (`base44/functions/<name>/entry.ts`). Base44 documents backend functions as Deno with a 5-minute timeout and 128 MB memory, so long local image/video jobs need an external worker or a split-step design.

## Porting inventory

| Route | Methods | Purpose | Suggested Base44 name |
| --- | --- | --- | --- |
| `/api/brain/answer` | POST | Grounded local answer | `brainAnswer` |
| `/api/brain/backup` | GET, POST | Brain backup list/create | `brainBackup` |
| `/api/brain/conversations` | GET, POST, DELETE | Conversation CRUD | `brainConversations` |
| `/api/brain/corrections` | POST | Save corrections | `brainCorrections` |
| `/api/brain/documents` | GET, POST, DELETE | Document CRUD/import | `brainDocuments` |
| `/api/brain/export` | GET | JSON/JSONL export | `brainExport` |
| `/api/brain/import` | POST | JSON import | `brainImport` |
| `/api/brain/knowledge` | GET, PATCH, DELETE | Knowledge CRUD | `brainKnowledge` |
| `/api/brain/research` | POST | Save web evidence | `brainResearch` |
| `/api/brain/restore` | POST | Restore backup | `brainRestore` |
| `/api/brain/retrieve` | POST | FTS + optional embeddings retrieval | `brainRetrieve` |
| `/api/brain/status` | GET | Brain status/counts | `brainStatus` |
| `/api/chat` | GET, POST | Legacy unwired provider route | omit unless adding provider |
| `/api/image/assets` | GET, POST | Visual assets | `imageAssets` |
| `/api/image/assets/[id]` | GET, DELETE | Serve/delete asset | `imageAssetById` |
| `/api/image/cancel` | POST | Cancel render job | `generationCancel` |
| `/api/image/datasets` | GET, POST | Visual datasets | `imageDatasets` |
| `/api/image/feedback` | POST | Image preference feedback | `imageFeedback` |
| `/api/image/generate` | POST | NDJSON local image stream | `imageGenerate` (external worker) |
| `/api/image/generated/[id]` | GET, DELETE | Serve/delete PNG | `imageGeneratedById` |
| `/api/image/reference` | GET | Wikimedia-only thumbnail proxy | `imageReference` |
| `/api/image/research` | POST | Opt-in visual research | `imageResearch` |
| `/api/image/status` | GET | Image engine status | `imageStatus` |
| `/api/image/upscale` | POST | NDJSON local upscale | `imageUpscale` (external worker) |
| `/api/network/status` | GET | Connectivity status | `networkStatus` |
| `/api/research/read` | GET, POST | Opt-in external page fetch | `researchRead` |
| `/api/research/search` | GET, POST | Opt-in web search | `researchSearch` |
| `/api/system/model-info` | GET | Runtime/model status | `systemModelInfo` |
| `/api/video/cancel` | POST | Cancel video job | `videoCancel` |
| `/api/video/generate` | POST | NDJSON keyframe video stream | `videoGenerate` (external worker) |
| `/api/video/generated/[id]` | GET, DELETE | Serve/delete WebM/poster | `videoGeneratedById` |
| `/api/video/status` | GET | Video engine status | `videoStatus` |

## Preserve these behaviors

- JSON errors use `{ "error": string }`.
- Image/video generate and upscale return newline-delimited JSON events (`queued`, `activity`, `progress`, `complete`, `error`).
- Generated asset responses use correct `Content-Type` values.
- Web search/read, Internet Study, and visual reference lookup are opt-in only.
- Research evidence keeps source/title/service/version/hash metadata and filters injected text.
- Image and video share one render slot with job-scoped cancellation.
- Video provenance says AI-image animation, not text-to-video.

## Auth and external integrations

DavidAI has no auth; Base44 deployment needs managed auth, entity security rules, and checks on mutating endpoints. Direct HTTP backend function calls have no user context, so use service-role only when intentional.

External integrations that actually run:

| Integration | When | Destination |
| --- | --- | --- |
| Web search/read | Only when explicitly enabled | Wikipedia/DuckDuckGo/Google News/Hacker News/arXiv and fetched pages |
| Wikimedia reference lookup | Only from Image page reference action | Wikimedia Commons with source/license metadata |
| Image model setup | Only when `npm run setup:image` is run manually | GitHub/Hugging Face downloads |

Local Qwen/image/video require `bin/` Windows binaries and `models/` GGUF weights. They cannot run directly in Base44's managed runtime.
