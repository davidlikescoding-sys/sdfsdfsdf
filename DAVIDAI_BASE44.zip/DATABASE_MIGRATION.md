# Database Migration

## Source

- Database: `data/brain/brain.sqlite`
- Schema version: `2` in `brain_meta`
- Engine: SQLite via Node `node:sqlite`, with FTS5 virtual tables
- Snapshot in `DAVIDAI_COMPLETE.zip`: consistent `VACUUM INTO` copy; source database and WAL were not modified
- Export in `DAVIDAI_BASE44.zip`: `DATA_EXPORT/schema.sql`, `brain_dump.json`, `counts.json`, `README.md`

`PRAGMA integrity_check` returned `ok`.

## Export-time counts

| Table | Rows |
| --- | ---: |
| conversations | 2 |
| messages | 8 |
| knowledge | 7 |
| documents | 0 |
| corrections | 1 |
| research | 1 |
| relations | 11 |
| retrieval_log | 221 |
| backups | 2 |
| embeddings | 17 |
| embeddings_v2 | 17 |
| training_promotions | 0 (legacy; do not recreate) |

## Entity mapping

Create these entities in Base44 manually or with the AI chat. No ready-made Base44 entity config is included because exact field types/security rules must be verified in your workspace.

| SQLite table | Suggested entity | Preserve |
| --- | --- | --- |
| `conversations` | `Conversation` | `id`, `title`, `created_at`, `updated_at` |
| `messages` | `Message` | `id`, `conversation_id`, `role`, `content`, `seq`, `created_at`, `metadata` |
| `knowledge` | `Knowledge` | core fields, v2 provenance fields, `hash`, `confidence`, `verification`, `related_ids`, `retrieval_count` |
| `documents` | `Document` | core fields, `hash`, v2 document provenance fields |
| `corrections` | `Correction` | links to knowledge/conversation/message, original/corrected text, `confidence` |
| `research` | `ResearchFinding` | title/content, source metadata, `hash`, `content_sha256` |
| `relations` | `Relation` | `from_id`, `to_id`, `kind`, `weight` |
| `retrieval_log` | `RetrievalLog` | query/result/score/timestamp; consider importing only recent rows |
| `backups` | `BrainBackup` | path/size/integrity/created_at metadata only |
| `embeddings` / `embeddings_v2` | `EmbeddingRecord` | `id`, `model`, `dim`, base64 `vector` if kept |
| `brain_meta` | App config or `AppMeta` | `schema_version` |

Do not create FTS5 virtual tables as entities. Rebuild search with Base44-supported fields/queries or an external search service.

## v1 to v2 additive fields

Schema v2 is additive and v1 exports remain compatible. Preserve these where present:

- On `knowledge`: `source_url`, `source_title`, `source_service`, `source_version`, `retrieved_at`, `last_modified`, `etag`, `valid_from`, `valid_to`, `supersedes_id`, `content_sha256`, `source_type`, `source_id`, `confidence`, `verification`, `related_ids`, `retrieval_count`, `updated_at`
- On `documents`: `path`, `section`, `symbol`, `language`, `doc_version`, `doc_sha256`, `retrieved_at`
- On `research`: `source_service`, `retrieved_at`, `published_at`, `last_modified`, `etag`, `content_sha256`
- `embeddings_v2` uses primary key `(id, model)`

## Import steps

1. Create the entities above with Base44 built-in fields (`id`, `created_date`, `updated_date`, `created_by`) rather than redefining them.
2. Add owner-based security rules; DavidAI previously had no auth.
3. Import rows from `DATA_EXPORT/brain_dump.json`, or flatten each table to CSV if Base44's importer expects CSV.
4. Convert base64 embedding objects only if your target store supports vectors; otherwise keep as text or regenerate.
5. Rebuild FTS/search behavior separately.
6. Verify counts against `counts.json` and spot-check conversation/message links and knowledge provenance.
7. Export browser `localStorage` separately from DavidAI Settings; it is not in the SQLite export or ZIPs.

BLOB values in `brain_dump.json` are encoded as `{ "__type": "base64", "base64": "..." }`.
