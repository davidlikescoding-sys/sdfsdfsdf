# Base44 Import Guide

Verified from Base44 documentation on 2026-11-24:

- <https://docs.base44.com/Getting-Started/migrating-an-existing-app.md>
- <https://docs.base44.com/developers/app-code/overview/project-structure.md>
- <https://docs.base44.com/base-code/getting-started.md>
- <https://docs.base44.com/developers/app-code/local-development/github.md>
- <https://docs.base44.com/developers/backend/overview/link-existing-project.md>
- <https://docs.base44.com/developers/references/cli/commands/create.md>

## Compatibility verdict

Base44's supported direct migrations are Salesforce, HubSpot, Shopify, WordPress, Lovable, Bolt.new, and Hopp by Wix. Base44 app projects use TanStack Start (default) or React Router with Vite and `@base44/sdk`.

DavidAI uses Next.js 16 App Router, `node:sqlite`, native Windows binaries, and local GGUF weights. There is no documented one-click importer for this stack. `DAVIDAI_BASE44.zip` is therefore a **manual reconstruction kit**, not a native Base44 project file. No unsupported Base44 config files were invented.

## Recommended path: managed Base44 reconstruction

1. Create a new Base44 app.
2. Attach `DAVIDAI_BASE44.zip` or paste the `DOCUMENTATION/*.md` files into the Base44 AI chat as context.
3. Ask Base44 to recreate the 17 routes and the `AppShell` navigation. Use `SOURCE_REFERENCE/src/app/**/page.tsx`, `src/components/**`, `src/lib/nav.ts`, `tailwind.config.ts`, and `src/app/globals.css` as the exact design reference.
4. Replace `next/font/google` with Base44-compatible font loading if needed; keep Manrope/Sora typography where possible.
5. Create entities and import data using `DATABASE_MIGRATION.md` + `DATA_EXPORT/`.
6. Rewrite the 32 API route files / 47 handlers using `API_INTEGRATIONS.md`.
7. Add managed auth and entity security rules. DavidAI currently has no auth.
8. Keep opt-in web research behavior. No external request should happen until the user enables it.
9. Decide how to handle local AI: self-hosted worker, client-side download, or documented removal. Do not fake generation.
10. Test pages, data, auth, and external integrations before publishing.

### Page route reconstruction map

| DavidAI route | Suggested Base44 route file |
| --- | --- |
| `/` | `src/routes/index.tsx` |
| `/chat` | `src/routes/chat.tsx` |
| `/image` | `src/routes/image.tsx` |
| `/datasets` | `src/routes/datasets.tsx` |
| `/architecture` | `src/routes/architecture.tsx` |
| `/training` | `src/routes/training.tsx` |
| `/internet-study` | `src/routes/internet-study.tsx` |
| `/monitor` | `src/routes/monitor.tsx` |
| `/evaluation` | `src/routes/evaluation.tsx` |
| `/dictionary` | `src/routes/dictionary.tsx` |
| `/memory` | `src/routes/memory.tsx` |
| `/learning` | `src/routes/learning.tsx` |
| `/sandbox` | `src/routes/sandbox.tsx` |
| `/checkpoints` | `src/routes/checkpoints.tsx` |
| `/experiments` | `src/routes/experiments.tsx` |
| `/knowledge` | `src/routes/knowledge.tsx` |
| `/settings` | `src/routes/settings.tsx` |

These are suggested TanStack-style names, not included final Base44 configs. Verify the structure that your Base44 app creates.

## Alternative: Base Code / GitHub

1. Extract `DAVIDAI_COMPLETE.zip`.
2. Create a GitHub repository. Avoid committing ~7.7 GiB of GGUF weights if repository limits apply; keep them in external storage and document the download step.
3. Go to <https://app.base44.com/base-code>, connect GitHub, and open the repo.
4. Use Base Code for AI-assisted editing/preview with the documentation as context.
5. Remember: Base Code is preview, not production hosting, and it keeps your own database/auth/routing.

## CLI note

Use `base44 create <name> --template backend-and-client` only after choosing to rebuild in Base44's supported structure. Do not run `base44 link` directly on the Next.js source; the docs say `link` expects a Base44 project containing `base44/config.jsonc`, which this project does not have.

## Must be recreated or configured in Base44

| Item | Action |
| --- | --- |
| Next.js App Router pages | Recreate in Base44's React/TanStack structure. |
| `src/app/api/**/route.ts` | Rewrite as server routes/functions. |
| SQLite + FTS5 | Recreate as Base44 entities/search or external search. |
| Browser `localStorage` | Export separately from DavidAI Settings. |
| llama.cpp / sd-cpp Windows binaries | Cannot run in managed Base44; use an external worker or redesign. |
| GGUF model weights | Host externally or download client-side where permitted. |
| Long image/video jobs | Base44 functions are documented at 5 minutes / 128 MB; split into steps or use an external worker. |
| Auth | Add Base44 managed auth and security rules. |
| Secrets | DavidAI needs none; if added, use Base44 secrets, not files. |
