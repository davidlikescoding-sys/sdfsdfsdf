# Environment Variables and Secrets

DavidAI needs no `.env.local`, API key, account, or paid provider for normal use.

`.env.example` contains only commented, inactive legacy provider placeholders:

```dotenv
# DAVIDAI_LLM_PROVIDER=openai-compatible
# DAVIDAI_LLM_BASE_URL=https://api.openai.com/v1
# DAVIDAI_LLM_API_KEY=sk-...
# DAVIDAI_LLM_MODEL=gpt-4o-mini
```

These variables are not used by the running app. Do not add real values unless you deliberately wire a provider.

## Local restore

| Requirement | Value |
| --- | --- |
| Node.js | `>=22.13.0` |
| Install | `npm ci` |
| Dev | `npm run dev` |
| Production | `npm run build` then `npm start` |
| Database | `data/brain/brain.sqlite`; no `DATABASE_URL` |
| Models | `models/llm/*.gguf`, `models/*.gguf`, `models/upscalers/*.gguf` |
| Binaries | `bin/llama-cpp/`, `bin/sd-cpp/` (Windows builds) |

Keep `models/`, `bin/`, and `data/` beside the source and manifests.

## Base44

If you add a provider during reconstruction, store credentials in Base44 secret storage:

```bash
npm install -g base44@latest
base44 login
base44 secrets set MY_PROVIDER_KEY=replace-with-real-key
```

Read secrets inside a backend function at request time:

```ts
import { secrets } from "base44:runtime";

export default async function (req: Request): Promise<Response> {
  const key = secrets.get("MY_PROVIDER_KEY");
  return Response.json({ configured: Boolean(key) });
}
```

Rules:

- Only `.env.example` is included; `.env` and `.env*.local` are excluded.
- Never put secrets in `NEXT_PUBLIC_*` variables.
- Do not commit `base44/.app.jsonc`; Base44 documents it as environment-specific.
- No real key, password, token, or private credential is included in either ZIP.
