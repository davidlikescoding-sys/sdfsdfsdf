# DavidAI — Final Export

Two packages only:

| ZIP | Purpose |
| --- | --- |
| `../DAVIDAI_COMPLETE.zip` | Full master backup: source, configs, public assets, scripts, Windows runtime binaries, GGUF models, generated data, and a consistent SQLite snapshot. |
| `../DAVIDAI_BASE44.zip` | Clean migration package: verified Base44 guidance, full source reference, database export, API mapping, safe `.env.example`, and documentation. |

## Read this first

Base44 does **not** document one-click import of a Next.js App Router project. DavidAI is Next.js 16 with `node:sqlite`, Windows `.exe`/`.dll` binaries, and local GGUF models. Those parts cannot run unchanged in Base44's managed runtime.

**Upload/use `DAVIDAI_BASE44.zip` first.** Attach it as context or source files when creating a new Base44 app, then follow `BASE44_IMPORT_GUIDE.md`. Use `DAVIDAI_COMPLETE.zip` only as the master backup/local runnable copy or to create a GitHub repo for Base Code.

## Fast path in Base44

1. Create a new Base44 app.
2. Attach or paste the contents of `DAVIDAI_BASE44.zip/DOCUMENTATION/` into the Base44 AI chat.
3. Have Base44 recreate the 17 pages and components from `SOURCE_REFERENCE/` while preserving branding and labels.
4. Create Base44 entities from `DATABASE_MIGRATION.md`; import `DATA_EXPORT/brain_dump.json` or flattened CSVs.
5. Rewrite API routes as Base44 server routes/functions from `API_INTEGRATIONS.md`.
6. Add Base44 auth/security rules before publishing.
7. Keep local Qwen/image/video either on a separate self-hosted worker or clearly mark those features as requiring reconstruction.

Browser `localStorage` data is not inside either ZIP. Export it from DavidAI Settings before leaving the old machine.

Security: no real keys, passwords, tokens, or credentials are included. Only `.env.example` is present. See `SECURITY_SCAN_REPORT.md` and `VERIFICATION_REPORT.md`.
