# Security Scan Report

Generated: 2026-11-24T23:01:41.9896113Z

## Scope

- Scanned 209 text/config/source files under davidai/src, davidai/scripts, davidai/public, root manifests, and the export DOCUMENTATION folder.
- Binary assets (gguf, exe, dll, png, sqlite) were not pattern-scanned; they are runtime/generated assets, not credential files.
- Excluded: node_modules, .next, build caches.

## Patterns checked

- OpenAI-style sk- keys
- GitHub ghp_/gho_/ghu_/ghs_/ghr_ tokens
- AWS AKIA access keys
- Google AIza API keys
- PEM private key headers
- Assigned api_key/apikey values with a long literal
- Assigned password values with a literal
- Bearer tokens with a long literal

## Results

- Credential-pattern hits: 0
- Environment files found in source: 1
- Environment files: .env.example
- Only .env.example is included in the export; it contains commented placeholders and no real value.
- No API key, password, token, or private credential was included in any package.

