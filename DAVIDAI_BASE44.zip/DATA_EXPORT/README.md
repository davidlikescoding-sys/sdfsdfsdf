# DavidAI brain data export

- Generated: 2026-11-24T22:55:58.531Z
- Source: `data/brain/brain.sqlite`
- Method: SQLite VACUUM INTO from a read-only connection

`schema.sql` is the full SQLite schema, including legacy tables and FTS virtual tables.
`brain_dump.json` contains every non-internal table. BLOB values (embeddings) are base64 objects.
`counts.json` records row counts and `brain_meta`. `training_promotions` is a legacy empty table and should not be recreated in Base44.

The live database was not modified.
