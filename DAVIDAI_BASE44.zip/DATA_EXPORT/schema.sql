-- index idx_backups_created
CREATE INDEX idx_backups_created ON backups(created_at DESC);

-- index idx_conversations_updated
CREATE INDEX idx_conversations_updated ON conversations(updated_at DESC);

-- index idx_corrections_created
CREATE INDEX idx_corrections_created ON corrections(created_at DESC);

-- index idx_documents_created
CREATE INDEX idx_documents_created ON documents(created_at DESC);

-- index idx_embeddings_model_created
CREATE INDEX idx_embeddings_model_created ON embeddings(model, created_at DESC);

-- index idx_embeddings_v2_model_created
CREATE INDEX idx_embeddings_v2_model_created ON embeddings_v2(model, created_at DESC);

-- index idx_knowledge_category
CREATE INDEX idx_knowledge_category ON knowledge(category);

-- index idx_knowledge_created
CREATE INDEX idx_knowledge_created ON knowledge(created_at DESC);

-- index idx_knowledge_source
CREATE INDEX idx_knowledge_source ON knowledge(source_type, source_id);

-- index idx_messages_conversation
CREATE INDEX idx_messages_conversation ON messages(conversation_id, seq);

-- index idx_messages_created
CREATE INDEX idx_messages_created ON messages(created_at DESC);

-- index idx_research_created
CREATE INDEX idx_research_created ON research(created_at DESC);

-- index idx_retrieval_log_created
CREATE INDEX idx_retrieval_log_created ON retrieval_log(created_at DESC);

-- index idx_training_promotions_created
CREATE INDEX idx_training_promotions_created ON training_promotions(created_at DESC);

-- index idx_training_promotions_knowledge
CREATE INDEX idx_training_promotions_knowledge ON training_promotions(knowledge_id);

-- table backups
CREATE TABLE backups (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      path TEXT NOT NULL,
      size INTEGER NOT NULL,
      integrity TEXT NOT NULL,
      created_at TEXT NOT NULL
    );

-- table brain_fts
CREATE VIRTUAL TABLE brain_fts USING fts5(
      id UNINDEXED,
      title,
      content,
      keywords,
      tokenize = 'unicode61 remove_diacritics 2'
    );

-- table brain_fts_config
CREATE TABLE 'brain_fts_config'(k PRIMARY KEY, v) WITHOUT ROWID;

-- table brain_fts_content
CREATE TABLE 'brain_fts_content'(id INTEGER PRIMARY KEY, c0, c1, c2, c3);

-- table brain_fts_data
CREATE TABLE 'brain_fts_data'(id INTEGER PRIMARY KEY, block BLOB);

-- table brain_fts_docsize
CREATE TABLE 'brain_fts_docsize'(id INTEGER PRIMARY KEY, sz BLOB);

-- table brain_fts_idx
CREATE TABLE 'brain_fts_idx'(segid, term, pgno, PRIMARY KEY(segid, term)) WITHOUT ROWID;

-- table brain_meta
CREATE TABLE brain_meta (
      key TEXT PRIMARY KEY,
      value TEXT NOT NULL
    );

-- table conversations
CREATE TABLE conversations (
      id TEXT PRIMARY KEY,
      title TEXT NOT NULL,
      created_at TEXT NOT NULL,
      updated_at TEXT NOT NULL
    );

-- table corrections
CREATE TABLE corrections (
      id TEXT PRIMARY KEY,
      knowledge_id TEXT NOT NULL,
      conversation_id TEXT NOT NULL,
      message_id TEXT NOT NULL,
      original TEXT NOT NULL,
      corrected TEXT NOT NULL,
      source TEXT NOT NULL,
      confidence REAL NOT NULL,
      created_at TEXT NOT NULL
    );

-- table document_fts
CREATE VIRTUAL TABLE document_fts USING fts5(
      id UNINDEXED,
      name,
      content,
      keywords,
      tokenize = 'unicode61 remove_diacritics 2'
    );

-- table document_fts_config
CREATE TABLE 'document_fts_config'(k PRIMARY KEY, v) WITHOUT ROWID;

-- table document_fts_content
CREATE TABLE 'document_fts_content'(id INTEGER PRIMARY KEY, c0, c1, c2, c3);

-- table document_fts_data
CREATE TABLE 'document_fts_data'(id INTEGER PRIMARY KEY, block BLOB);

-- table document_fts_docsize
CREATE TABLE 'document_fts_docsize'(id INTEGER PRIMARY KEY, sz BLOB);

-- table document_fts_idx
CREATE TABLE 'document_fts_idx'(segid, term, pgno, PRIMARY KEY(segid, term)) WITHOUT ROWID;

-- table documents
CREATE TABLE documents (
      id TEXT PRIMARY KEY,
      name TEXT NOT NULL,
      content TEXT NOT NULL,
      category TEXT NOT NULL,
      keywords TEXT NOT NULL,
      source TEXT NOT NULL,
      hash TEXT NOT NULL UNIQUE,
      created_at TEXT NOT NULL
    , path TEXT, section TEXT, symbol TEXT, language TEXT, doc_version TEXT, doc_sha256 TEXT, retrieved_at TEXT);

-- table embeddings
CREATE TABLE embeddings (
      id TEXT PRIMARY KEY,
      model TEXT NOT NULL,
      vector BLOB NOT NULL,
      dim INTEGER NOT NULL,
      created_at TEXT NOT NULL
    );

-- table embeddings_v2
CREATE TABLE embeddings_v2 (
      id TEXT NOT NULL,
      model TEXT NOT NULL,
      vector BLOB NOT NULL,
      dim INTEGER NOT NULL,
      created_at TEXT NOT NULL,
      PRIMARY KEY (id, model)
    );

-- table knowledge
CREATE TABLE knowledge (
      id TEXT PRIMARY KEY,
      title TEXT NOT NULL,
      content TEXT NOT NULL,
      category TEXT NOT NULL,
      keywords TEXT NOT NULL,
      source TEXT NOT NULL,
      source_type TEXT NOT NULL,
      source_id TEXT,
      confidence REAL NOT NULL,
      verification TEXT NOT NULL,
      related_ids TEXT NOT NULL,
      hash TEXT NOT NULL UNIQUE,
      created_at TEXT NOT NULL,
      updated_at TEXT NOT NULL,
      retrieval_count INTEGER NOT NULL DEFAULT 0
    , source_url TEXT, source_title TEXT, source_service TEXT, source_version TEXT, retrieved_at TEXT, last_modified TEXT, etag TEXT, valid_from TEXT, valid_to TEXT, supersedes_id TEXT, content_sha256 TEXT);

-- table message_fts
CREATE VIRTUAL TABLE message_fts USING fts5(
      id UNINDEXED,
      conversation_id UNINDEXED,
      content,
      tokenize = 'unicode61 remove_diacritics 2'
    );

-- table message_fts_config
CREATE TABLE 'message_fts_config'(k PRIMARY KEY, v) WITHOUT ROWID;

-- table message_fts_content
CREATE TABLE 'message_fts_content'(id INTEGER PRIMARY KEY, c0, c1, c2);

-- table message_fts_data
CREATE TABLE 'message_fts_data'(id INTEGER PRIMARY KEY, block BLOB);

-- table message_fts_docsize
CREATE TABLE 'message_fts_docsize'(id INTEGER PRIMARY KEY, sz BLOB);

-- table message_fts_idx
CREATE TABLE 'message_fts_idx'(segid, term, pgno, PRIMARY KEY(segid, term)) WITHOUT ROWID;

-- table messages
CREATE TABLE messages (
      id TEXT PRIMARY KEY,
      conversation_id TEXT NOT NULL,
      role TEXT NOT NULL,
      content TEXT NOT NULL,
      created_at TEXT NOT NULL,
      seq INTEGER NOT NULL,
      metadata TEXT,
      FOREIGN KEY (conversation_id) REFERENCES conversations(id) ON DELETE CASCADE
    );

-- table relations
CREATE TABLE relations (
      id TEXT PRIMARY KEY,
      from_id TEXT NOT NULL,
      to_id TEXT NOT NULL,
      kind TEXT NOT NULL,
      weight REAL NOT NULL,
      created_at TEXT NOT NULL,
      UNIQUE(from_id, to_id, kind)
    );

-- table research
CREATE TABLE research (
      id TEXT PRIMARY KEY,
      title TEXT NOT NULL,
      content TEXT NOT NULL,
      source_url TEXT,
      source_title TEXT,
      keywords TEXT NOT NULL,
      hash TEXT NOT NULL UNIQUE,
      created_at TEXT NOT NULL
    , source_service TEXT, retrieved_at TEXT, published_at TEXT, last_modified TEXT, etag TEXT, content_sha256 TEXT);

-- table research_fts
CREATE VIRTUAL TABLE research_fts USING fts5(
      id UNINDEXED,
      title,
      content,
      keywords,
      tokenize = 'unicode61 remove_diacritics 2'
    );

-- table research_fts_config
CREATE TABLE 'research_fts_config'(k PRIMARY KEY, v) WITHOUT ROWID;

-- table research_fts_content
CREATE TABLE 'research_fts_content'(id INTEGER PRIMARY KEY, c0, c1, c2, c3);

-- table research_fts_data
CREATE TABLE 'research_fts_data'(id INTEGER PRIMARY KEY, block BLOB);

-- table research_fts_docsize
CREATE TABLE 'research_fts_docsize'(id INTEGER PRIMARY KEY, sz BLOB);

-- table research_fts_idx
CREATE TABLE 'research_fts_idx'(segid, term, pgno, PRIMARY KEY(segid, term)) WITHOUT ROWID;

-- table retrieval_log
CREATE TABLE retrieval_log (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      query TEXT NOT NULL,
      result_id TEXT NOT NULL,
      result_type TEXT NOT NULL,
      score REAL NOT NULL,
      created_at TEXT NOT NULL
    );

-- table sqlite_sequence
CREATE TABLE sqlite_sequence(name,seq);

-- table training_promotions
CREATE TABLE training_promotions (
      id TEXT PRIMARY KEY,
      knowledge_id TEXT NOT NULL,
      note TEXT,
      model_version TEXT,
      created_at TEXT NOT NULL
    );
